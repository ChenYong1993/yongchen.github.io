# code oblique_stripe_removal
********************************************************************************
 A sheared low-rank model for oblique stripe removal
********************************************************************************

 Copyright:     Jian-Li Wang , Ting-Zhu Huang, Tian-Hui Ma, Xi-Le Zhao, Yong Chen
                   
********************************************************************************
********************************************************************************
  1). Details
  
  More detail can be found in [1]

  [1] A sheared low-rank model for oblique stripe removal,
      Jian-Li Wang, Ting-Zhu Huang, Tian-Hui Ma, Xi-Le Zhao, Yong Chen,
      Applied Mathematics and Computation: 2019, 360, 167--180
********************************************************************************

  2). Please cite our paper if you use any part of our source code.
