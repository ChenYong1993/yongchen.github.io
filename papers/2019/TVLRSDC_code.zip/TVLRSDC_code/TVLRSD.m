function [X,S,N,out] = TVLRSD(Y,opt,b)
%% ---------------------------------------------------------------------------
%     Model: 
%      min_{X, S, N} 1/2||N||_F^2 + lambda_1 ||X||_* + lambda_2 ||S||_{1} + lambda_3 sum_i
%      ||DS_i||_1 
%        s.t.  Y = X + S + N

%      ADMM solver
%      min_{1/2||N||_F^2 + lambda_1 ||X||_* lambda_2 ||R||_{1} 
%              + lambda_3 sum_i ||Q_i||_1 
%       s.t.  Y = X + S + N, R = S, Q_i = DS_i
% ---------------------------------------------------------------------------
% Input:
%     Y \in R^{m*n*bt}: cloud/shadow image m,n: spatail size b,t: band
%                      number and time number
%     opt: regularization parameter 
%     opt(1): image low-rank regularization parameter
%     opt(2): cloud/shadow sparse regularization parameter
%     opt(3): cloud/shadow TV regularization parameter
%     opt(4): ADMM positive penalty parameter
%       b: the number of band in each time node
% Output:
%     X: image component via TVLRSD
%     S: cloud/shadow component via TVLRSD
%     N: residual
%     out: Relative change
% ---------------------------------------------------------------------------
% Reference paper: 
%    Y. Chen, W. He, N. Yokoya, and T.-Z. Huang,  Blind cloud and cloud shadow removal of
%    multitemporal images based on total variation regularized low-rank sparsity decomposition. 
%    ISPRS Journal of Photogrammetry and Remote Sensing, 2019, 157: 93-107.
lambda1 = opt(1);
lambda2 = opt(2);
lambda3 = opt(3);
beta  = opt(4);
 % init. variables 
[m,n,p] = size(Y);
sizeD = [m,n,b,p/b];
S = zeros(m,n,p);
N = zeros(m,n,p);
X = Y;

W1 = zeros(size(Y));
W2 = zeros(m,n,b,3,p/b);
W3 = zeros(size(Y));

Eny_x   = ( abs(psf2otf([+1; -1], [m,n,b])) ).^2  ;
Eny_y   = ( abs(psf2otf([+1, -1], [m,n,b])) ).^2  ;
Eny_z   = ( abs(psf2otf([+1, -1], [n,b,m])) ).^2  ;
Eny_z   =  permute(Eny_z, [3, 1 2]);
denom1  =  Eny_x + Eny_y + Eny_z;
%
maxIter = 500;
relChgXPath = zeros(maxIter, 1);
relChgSPath = zeros(maxIter, 1);
tol = 1e-4;
isCont  = 0;
display  = 0;
DS = diff3(S,sizeD);
for iter = 1 : maxIter
     fprintf('\n*****************************iter: %d ******************************\n', iter');
     X_pre = X; S_pre = S; 
     
     % R subproblem
     R = softThres(S - W1/beta, lambda2/beta);
     
     % Q subproblem
     Q = softThres(DS - W2/beta, lambda3/beta);
     
     % X subproblem
    tem = Y - S - N + W3/beta;
    temp = reshape(tem,m*n,p);
    [U,sigma,V] = svd(temp,'econ');
    sigma = diag(sigma);
    svp = length(find(sigma>lambda1/(beta)));
    X = U(:, 1:svp) * diag(sigma(1:svp) - lambda1/(beta)) * V(:, 1:svp)';  
    X = reshape(X,m,n,p);
    
     % S subproblem
     for i = 1:p/b
         DTS = diffT3(Q(:,:,:,:,i) + W2(:,:,:,:,i)/beta, sizeD);
         temp_x2 = DTS + (Y(:,:,(1+(i-1)*b):i*b) - X(:,:,(1+(i-1)*b):i*b)...
                   - N(:,:,(1+(i-1)*b):i*b) + W3(:,:,(1+(i-1)*b):i*b)/beta) + ...
                   (R(:,:,(1+(i-1)*b):i*b)  + W1(:,:,(1+(i-1)*b):i*b)/beta);
         S(:,:,(1+(i-1)*b):i*b)  = real( ifftn( fftn(temp_x2) ./ (denom1 + 2) ) );
     end
     
     % N subproblem
     N = beta*(Y - X - S + W3/beta)./(1 + beta);
     
     % update W1 W2 W3
     DS = diff3(S, sizeD);
     W1 = W1 + beta*(R - S);
     W2 = W2 + beta*(Q - DS);
     W3 = W3 + beta*(Y - S - X - N);

     %
    relChgX = norm(X(:) - X_pre(:),'fro')/max(1,norm(X_pre(:),'fro'));
    relChgS = norm(S(:) - S_pre(:),'fro')/max(1,norm(S_pre(:),'fro'));
    relChgXPath(iter) = relChgX;
    relChgSPath(iter) = relChgS;
	if  display
        fprintf('relChgX:%4.4e, relChgS: %4.4e \n', relChgX, relChgS);
    end
    
    %- 
      if  isCont
            nr1 = norm(R(:) - S(:), 'fro');
            nr2 = norm(Q(:) - DS(:),'fro');
            nr3 = norm(Y(:) - S(:) - X(:), 'fro');        
            if display             
               fprintf('nr1(R-S): %4.4e,nr2(Q-DS): %4.4e, nr2(Y-S-X): %4.4e\n  \n',nr1,nr2,nr3);
            end
      
      end       

    if (relChgX < tol ) 
          disp(' !!!stopped by termination rule!!! ');  break;
    end

end
%
out.iter     = iter;
out.relChgXPath = relChgXPath(1:iter);
out.relChgSPath = relChgSPath(1:iter);
 end
%%  subFunctions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% compute the diff. of one 3-order tensor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function diff_x = diff3(x,  sizeD)
diff_x = zeros(sizeD(1),sizeD(2),sizeD(3),3,sizeD(4));
for i = 1:sizeD(4)
tenX   = x(:,:,(1 + (i-1)*sizeD(3)):i*sizeD(3));

dfx1     = diff(tenX, 1, 1);
dfy1     = diff(tenX, 1, 2);
dfz1     = diff(tenX, 1, 3);

dfx      = zeros(sizeD(1),sizeD(2),sizeD(3));
dfy      = zeros(sizeD(1),sizeD(2),sizeD(3));
dfz      = zeros(sizeD(1),sizeD(2),sizeD(3));
dfx(1:end-1,:,:) = dfx1;
dfx(end,:,:)     =  tenX(1,:,:) - tenX(end,:,:);
dfy(:,1:end-1,:) = dfy1;
dfy(:,end,:)     = tenX(:,1,:) - tenX(:,end,:);
dfz(:,:,1:end-1) = dfz1;
dfz(:,:,end)     = tenX(:,:,1) - tenX(:,:,end);
diff_x(:,:,:,1,i) = dfx;
diff_x(:,:,:,2,i) = dfy;
diff_x(:,:,:,3,i) = dfz;
end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  compute the inverse-diff. of one 3-order tensor 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function diffT_a = diffT3(a, sizeD)

tenX = a(:,:,:,1);
tenY = a(:,:,:,2);
tenZ = a(:,:,:,3);
dfx     = diff(tenX, 1, 1);
dfy     = diff(tenY, 1, 2);
dfz     = diff(tenZ, 1, 3);

dfxT   = zeros(sizeD(1),sizeD(2),sizeD(3));
dfyT   = zeros(sizeD(1),sizeD(2),sizeD(3));
dfzT   = zeros(sizeD(1),sizeD(2),sizeD(3));
dfxT(1,:,:) = tenX(end, :, :) - tenX(1, :, :); %
dfxT(2:end,:,:) = -dfx;
dfyT(:,1,:)     =  tenY(:,end,:) - tenY(:,1,:);
dfyT(:,2:end,:) = -dfy;
dfzT(:,:,1)     = tenZ(:,:,end) - tenZ(:,:,1);
dfzT(:,:,2:end) = -dfz;

diffT_a = dfxT + dfyT + dfzT;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  x^* = argmin_x 0.5*(x-a) + \lambda * |x|
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = softThres(a, tau)

x = sign(a).* max( abs(a) - tau, 0);
end

