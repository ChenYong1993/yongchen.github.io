function X1 = Information_compensation(Noi,X,S,tau,b)
[h,w,p] = size(X);
Mask = zeros(h,w,p);
for i = 1:p/b
S1 = S(:,:,((i-1)*b+1):i*b);
va = mean(S1,3);
P = zeros(h,w);
m = find(va>tau); %cloud: larger than a threshold value 
P(m) = 1;
Mask(:,:,((b*(i-1)+1):b*i)) = repmat(P,1,1,b);
end
index = find(Mask==0);
X1 = X;
X1(index) = Noi(index);
