% This package contains a matlab implementation of the TVLRSD algorithm 
% for cloud/shadow removal [1].

% Pleae run the "demo.m" file,
% which will run our algorithm on the simulated case 1 in our paper.

% If you use the code or data, please cite the related papers:
%
% [1] Y. Chen, W. He, N. Yokoya, and T.-Z. Huang,  Blind cloud and cloud shadow removal of
%    multitemporal images based on total variation regularized low-rank sparsity decomposition. 
%    ISPRS Journal of Photogrammetry and Remote Sensing, 2019, 157: 93-107.
%
% Author: Yong Chen 
% E-mail addresses:(chenyong1872008@163.com)
