clc,clear,close all
load Data    % time node = 4, band = 4, corresponding simulated case 1 in our paper
[m, n, b, t] = size(Clean);
Clean = reshape(Clean,m,n,b*t);
Noi = reshape(Cloud_image,m,n,b*t);
Mask = reshape(Mask,m,n,b*t);
index = find(Mask==1);
b = 4;            % the number of band in each time node
%% different dataset may need change regularization parameters slightly.
Lambda1 = 1;      % image low-rank regularization parameter
Lambda2 = 0.001;  % cloud/shadow sparse regularization parameter
Lambda3 = 0.005;  % cloud/shadow TV regularization parameter
beta = 0.1; 
para = [Lambda1 Lambda2 Lambda3 beta];
%%
[X_TVLRSD,S,N,out] = TVLRSD(Noi,para,b);
[psnr_TVLRSD, ssim_TVLRSD] = MSIQA(Clean*255, X_TVLRSD  * 255);
%%
tau = 0.7;  % cloud threshold value, different dataset may need change the threshold value.
X_TVLRSDC = Information_compensation(Noi,X_TVLRSD,S,tau,b);
[psnr_TVLRSDC, ssim_TVLRSDC] = MSIQA(Clean*255, X_TVLRSDC * 255);
%%
X_TVLRSDR = X_TVLRSD;
X_TVLRSDR(index) = Noi(index);
[psnr_TVLRSDR, ssim_TVLRSDR] = MSIQA(Clean*255, X_TVLRSDR*255);
%% 
fprintf('TVLRSD: psnr = %f, ssim = %f.\r\n',psnr_TVLRSD,ssim_TVLRSD);
fprintf('-------------------------------------------------------------\r\n');
fprintf('TVLRSDC: psnr1 = %f, ssim1 = %f.\r\n',psnr_TVLRSDC,ssim_TVLRSDC);
fprintf('-------------------------------------------------------------\r\n');
fprintf('TVLRSDR: psnr2 = %f, ssim2 = %f.\r\n',psnr_TVLRSDR,ssim_TVLRSDR);
figure
subplot(131),imshow(Clean(:,:,[4 2 1])*2,[]) ,title('Orignal-time node 1')
subplot(132),imshow(Noi(:,:,[4 2 1])*2,[]) ,title('simulated cloud-time node 1')
subplot(133),imshow(X_TVLRSDC(:,:,[4 2 1])*2,[]), title('TVLRSDC-time node 1')