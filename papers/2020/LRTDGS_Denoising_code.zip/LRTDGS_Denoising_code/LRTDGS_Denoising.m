function [clean_image,S,out,time] = LRTDGS_Denoising(Noi, lambda1, lambda2, rank)
%% ---------------------------------------------------------------------------
%     Model: 
%      min_{X, S, G, U_i} lambda_1 ||W * DX||_{2,1} + lambda_2 ||S||_1
%        s.t.  X = G * U_1 * U_2 * U_3, ||Y - X - S||_F^2 < epsilon

%      ALM solver
%      min_{X, S, G, U_i, R, Q} lambda_1 ||W * R||_{2,1} + lambda_2 ||S||_1
%       s.t.  X = G * U_1 * U_2 * U_3, ||Y - X - S||_F^2 < epsilon, X = Q, DQ = R
% ---------------------------------------------------------------------------
% Reference paper: 
%    Y. Chen, W. He, N. Yokoya, and T.-Z. Huang, �Hyperspectral image restoration using 
%    weighted group sparsity regularized low-rank tensor decomposition,� IEEE Trans.
%    Cybernetics, 2019
tic
sizeD = size(Noi);
maxIter = 100;
error = 1e-4;  
beta = 0.01; 

out       = [];
out.SSIM  = [];
out.PSNR  = [];
out.rel_error = [];

M = sizeD(1);
N = sizeD(2);
p = sizeD(3);
%% 
Eny_x_fft   = (abs(psf2otf([+1; -1], [M,N,p]))).^2  ;
Eny_y_fft   = (abs(psf2otf([+1, -1], [M,N,p]))).^2  ;
Eny_fft  =  Eny_x_fft + Eny_y_fft;

%%  Initialization 
X = Noi;                % X :  restored image
Q = X;                  % Q :  auxiliary variable for X
S = zeros(sizeD);       % S :  sparse noise 
R1 = zeros(sizeD);      % R1 : auxiliary variable for GS_x
R2 = zeros(sizeD);      % R2 : auxiliary variable for GS_y
W3 = R1;                % W3 : multiplier for DQ_x-R1
W4 = R2;                % W4 : multiplier for DQ_y-R2
W1 = zeros(size(Noi));  % W1 : multiplier for Y - X - S          
W2 = W1;                % W2 : multiplier for X - Q     

%% ALM iteration
for iter = 1 : maxIter
    preX = X;
    
    %% - Core and U_i and X subproblem update 
    temp = 1/2 * (Noi - S + Q + (W1 - W2) / beta);
    X = tucker_hooi(temp, rank);
    
    %% - Q subproblem update     
    diffT_p = diffT3(beta * R1 - W3, beta * R2 - W3, sizeD);
    temp1 = reshape(diffT_p + beta*X + W2, sizeD);
    z = real(ifftn(fftn(temp1) ./ (beta*Eny_fft + beta)));
    Q = reshape(z,sizeD);
    
    %% - R1 and R2 subproblem update
    [diff_Qx, diff_Qy] = diff3(Q, sizeD); 
    R1 = Thres_21(diff_Qx+ W3/beta, lambda1/beta);  
    R2 = Thres_21(diff_Qy+ W4/beta, lambda1/beta);
    
    %% - S subproblem update
    S = softthre(Noi-X+W1/beta,lambda2/beta);
    
    %% - multiplier W1 and W2 update 
    W1 = W1 + beta*(Noi-X-S);
    W2 = W2 + beta*(X-Q); 
    
    %% - multiplier W3 and W4 update
    W3 = W3+beta*(diff_Qx-R1);    
    W4 = W4+beta*(diff_Qy-R2);  
    beta = min(beta *1.5,1e6); 
    
    %% compute the error
    out.rel_error(iter) = norm(X(:)-preX(:),'fro') / norm(preX(:),'fro');
    fprintf('LRTDGS: iterations = %d  reX=%f\n', iter, out.rel_error(iter));
    if out.rel_error(iter) < error
        break;  
    end 
    %% compute SSIM and PSNR values
%   [out.PSNR(iter),out.SSIM(iter)]=MSIQA(simu_indian*255,X*255);
end
clean_image = X;
toc
time=toc; 
end

