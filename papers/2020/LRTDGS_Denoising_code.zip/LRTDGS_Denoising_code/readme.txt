% This package contains a matlab implementation of the proposed LRTDGS denoising algorithm [1].
%
% Pleae run the "Exp.m" file,
% 
% If you use the code, please refer to related papers:
%
%[1] Yong Chen, Wei He*, Naoto Yokoya, and Ting-Zhu Huang, "Hyperspectral image restoration using weighted group 
%    sparsity-regularized low-rank tensor decomposition." IEEE Transactions on Cybernetics,2020, 50(8): 3556-3570.
%
% E-mail addresses:(chenyong1872008@163.com)
