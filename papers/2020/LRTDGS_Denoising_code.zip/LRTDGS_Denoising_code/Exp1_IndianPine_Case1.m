clc
clear
addpath function
addpath quality_assess
addpath data
%% Simulated Indian Pines dataset case 1
rng(1)
load simu_indian
Omsi = simu_indian;
noiselevel = 0.15*ones(1,224); 
Nmsi = Omsi;
[M,N,p] = size(Omsi);
%%% Gaussian noise
for i = 1:p
     Nmsi(:,:,i)=Omsi(:,:,i)  + noiselevel(i)*randn(M,N);
end
%%
lambda1 = 0.8;                % parameter for group sparse term
lambda2 = 50/(sqrt(M*N));     % parameter for sparse noise
Rank   = [120,120,10];        % parameter for Tucker rank
tic
[LRTDGS_rec,S,out_value,time] = LRTDGS_Denoising(Nmsi,lambda1,lambda2,Rank);
toc
[psnr, ssim, fsim, ergas, msam] = MSIQA(simu_indian*255,LRTDGS_rec*255);