clc
clear
addpath function
addpath quality_assess
addpath data
%% Simulated Indian Pines dataset case 3 
rng(1)
load simu_indian
load Indian_G_noiselevel_0_2
load Indian_Impuse_ratio_0_2
Omsi       = simu_indian; 

Nmsi      = Omsi;
[M,N,p]   = size(Omsi);
%%% Gaussian noise
for i = 1:p
     Nmsi(:,:,i)=Omsi(:,:,i)  + noiselevel(i)*randn(M,N);
end

%%% S&P noise
for i = 1:p
     Nmsi(:,:,i)=imnoise(Nmsi(:,:,i),'salt & pepper',ratio(i));
end
%%
lambda1 = 0.8;                % parameter for group sparse term
lambda2 = 100/(sqrt(M*N));     % parameter for sparse noise
Rank   = [120,120,10];        % parameter for Tucker rank
[LRTDGS_rec,S,out_value,time] = LRTDGS_Denoising(Nmsi,lambda1,lambda2,Rank);
[psnr, ssim, fsim, ergas, msam] = MSIQA(simu_indian*255,LRTDGS_rec*255);