clear all;
close all;
clc;	
addpath(genpath('TRD_function\')); 
addpath(genpath('quality_assess\')); 
%% simulated experiment
nSigrange = 100;
eva_BM3D = {};
eva_BM4D = {};
eva_LRTA = {};
eva_PARAFAC = {};
eva_LRMR = {};
eva_TDL = {};
eva_KBR = {};
eva_LLRT = {};
eva_NLTR = {};
load Test
randn('seed', 0);
nSig = nSigrange/255;
N_Img = O_Img/255 + nSig * randn(size(O_Img));   % add Gaussian noise [0,1]
%% choose comparing methods
Comparison_BM3D = 0;             
Comparison_BM4D = 0;        
Comparison_LRTA = 0;
Comparison_PARAFAC = 0;       
Comparison_LRMR = 0;              
Comparison_TDL = 0;            
Comparison_tSVD = 0;       
Comparison_KBR = 0;
Comparison_LLRT = 0;
Comparison_NLTR = 1;          
%% BM3D denoising
if Comparison_BM3D == 1 
    BM3D_Img   =  N_Img;
    t = clock;
    for k = 1:size(N_Img,3)
        [~, BM3D_Img(:,:,k)] = BM3D(1,N_Img(:,:,k), nSig*255);  %noisy: [0-1]or[0-255],Sigma [0-255]
    end
    eva_BM3D.Time = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, BM3D_Img*255);
eva_BM3D.PIQ = [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:BM3D      ', ', Time = ' num2str(eva_BM3D.Time), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end
%% BM4D denoising
if Comparison_BM4D == 1 
    t = clock;
    [~, BM4D_Img] = bm4d(1, N_Img, nSig);         %noisy: [0-1],Sigma [0-1]
    eva_BM4D.Time  = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, BM4D_Img*255);
eva_BM4D.PIQ = [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:BM4D      ', ', Time = ' num2str(eva_BM4D.Time), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end
%% LRTA
if Comparison_LRTA == 1 
    t = clock;
    LRTA_Img = double(LRTA(tensor(N_Img)));       %noisy: [0-1],Sigma [0-1]
    eva_LRTA.Time  = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, LRTA_Img*255);
eva_LRTA.PIQ = [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:LRTA      ', ', Time = ' num2str(eva_LRTA.Time), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end
%% LRMR
if Comparison_LRMR == 1
    Par        =  ParamSet(nSig*255);
    t = clock;
    LRMR_Img   =  LRMR_DeNoising( N_Img*255, Par );
    eva_LRMR.Time  = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, LRMR_Img);
eva_LRMR.PIQ= [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:LRMR      ', ', Time = ' num2str(eva_LRMR.Time), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end
%% PARAFAC
if Comparison_PARAFAC == 1
   t = clock;
   [PARAFAC_Img, k] = PARAFAC(tensor(N_Img));
   eva_PARAFAC.Time = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, PARAFAC_Img*255);
eva_PARAFAC.PIQ = [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:PARAFAC      ', ', Time = ' num2str(eva_PARAFAC.Time), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end
%% TDL
if Comparison_TDL == 1
    vstbmtf_params.peak_value = 1;
    vstbmtf_params.nsigma = nSig;
    t = clock;
    TDL_Img = TensorDL(N_Img, vstbmtf_params);
    eva_TDL.Time = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, TDL_Img*255);
eva_TDL.PIQ = [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:TDL      ', ', Time = ' num2str(eva_TDL.Time), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end
%% KBP
if Comparison_KBR == 1
    t = clock;
    KBR_Img = KBR_DeNoising(N_Img, nSig, 1);
    eva_KBR.Time  = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, KBR_Img*255);
eva_KBR.PIQ = [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:KBR     ', ', Time = ' num2str(eva_KBR.Time), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end
%% LLRT
if Comparison_LLRT == 1
    %addpath ./compete_methods/LLRT
    Par   = ParSet(nSig*255);  
    t = clock;
    LLRT_Img = LLRT_DeNoising( N_Img*255, O_Img, Par);
    eva_LLRT.Time  = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, LLRT_Img);
eva_LLRT.PIQ = [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:LLRT     ', ', Time = ' num2str(eva_LLRT.Time(ii,jj)), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end
%% NLTR
if Comparison_NLTR == 1
    [par,TRParSet] = ParSetTR(nSig*255);  
    t = clock;
    NLTR_Img = NLTR_DeNoising(N_Img,par,TRParSet); 
    eva_NLTR.Time  = etime(clock,t);
[psnr, ssim, fsim, ergas, msam] = MSIQA(O_Img, NLTR_Img*255);
eva_NLTR.PIQ = [psnr, ssim, fsim, ergas, msam];

disp(['Method Name:NLTR     ', ', Time = ' num2str(eva_NLTR.Time), ', MPSNR=' num2str(psnr,'%5.2f')  ...
           ',MSSIM = ' num2str(ssim,'%5.4f'), ', Sigma = ' num2str(nSigrange)]);
end