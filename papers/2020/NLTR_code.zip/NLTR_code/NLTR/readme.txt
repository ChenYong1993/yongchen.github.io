% This package contains a matlab implementation of the proposed NLTR denoising algorithm [1].
%
% Pleae run the "demo.m" file,
% 
% If you use the code, please cite the related paper:
%
%[1] Y. Chen, W. He, N. Yokoya, T.-Z. Huang, and X.-L. Zhao, ��Nonlocal tensor-ring decomposition for hyperspectral image denoising,�� 
%    IEEE Trans. Geosci. Remote Sens., vol. 58, no. 2, pp. 1348�C1362, Feb. 2020.
%
% E-mail addresses:(chenyong1872008@163.com)
