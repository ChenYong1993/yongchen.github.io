function X  =  TR_dec(Y,Par,TRParSet)
sizeD = size(Y);
Y = reshape(Y,Par.patsize*Par.patsize,sizeD(1)/((Par.patsize)*(Par.patsize)),sizeD(2));
r = TRParSet.r; 
maxiter = TRParSet.maxiter; 
Lamda = TRParSet.lambda; 
rho = TRParSet.rho; 
N = ndims(Y);
S = size(Y);
G = TR_initcoreten(S,r);
iter = 0;
while iter < maxiter
      iter = iter+1;
      % update G
      for n = 1:N
      Q = tenmat_sb(Z_neq(G,n),2);  Q=Q'; % Q is the right part of the right part of the relation equation
      G{n} = Gfold((2*Lamda*tenmat_sb(Y,n)*Q'+rho*Gunfold(G{n},2))/((2*Lamda*(Q*Q')...
            +rho*eye(size(Q,1),size(Q,1)))),size(G{n}),2);
      end
end
% update X
X = coreten2tr(G);
X = reshape(X,sizeD);