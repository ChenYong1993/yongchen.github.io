function [E_Temp] = NLTRPatEstimation(Temp, Par,TRParSet)                            % For each keypatch group
 
            M_Temp  =   repmat(mean( Temp, 2 ),1,Par.patnum);
            Temp    =   Temp - M_Temp;
            E_Temp 	=   TR_dec(Temp, Par, TRParSet) + M_Temp; % TR Estimation
end