function [E_Img]   =  NLTR_DeNoising( N_Img, Par,TRParSet)
%%
E_Img            = N_Img;                                                         % Estimated Image[Height, Width, Band]  = size(E_Img);   
Average          = mean(N_Img,3);                                                 % Calculate the average band for fast spatial non-local searching
[Neighbor_arr, Num_arr, Self_arr] =	NeighborIndex(Average, Par);                  % PreCompute all the patch index in the searching window 
[Height, Width, Band]  = size(E_Img);  
%psnr_p = 0;
%%
for iter = 1 : Par.deNoisingIter    
    E_Img      	    = E_Img + Par.delta*(N_Img - E_Img);     
    Average         =   mean(E_Img,3);
    [CurPat, Mat]	=	Cub2Patch( E_Img, N_Img, Average, Par );      % Cubic to patch and estimate local noise variance
    %%
    if (mod(iter-1,2)==0)
        Par.patnum = Par.patnum - 10;                                             % Lower Noise level, less NL patches
        NL_mat  =  Block_matching(Mat, Par, Neighbor_arr, Num_arr, Self_arr);     % Caculate Non-local similar patches for each
    end
    %%
    EPat = zeros(size(CurPat));
    W    = zeros(size(CurPat));
    Temp = cell(length(Self_arr),1);
    E_Temp = cell(length(Self_arr),1);
    %%
    for i = 1:length(Self_arr) 
        Temp{i} =  CurPat(:, NL_mat(1:Par.patnum,i));                  % Non-local similar patches to the keypatch
    end
    %%
    parfor i = 1:length(Self_arr)  
    E_Temp{i}    =  NLTRPatEstimation(Temp{i},Par,TRParSet); 
    end
    %%
    for  i      =  1 : length(Self_arr)                                 % For each keypatch group
     EPat(:,NL_mat(1:Par.patnum,i))  = EPat(:,NL_mat(1:Par.patnum,i)) + E_Temp{i};      
     W(:,NL_mat(1:Par.patnum,i))     = W(:,NL_mat(1:Par.patnum,i)) + ones(size(CurPat,1),size(NL_mat(1:Par.patnum,i),1));
    end
    %%
    % Estimate the spatial patches
    [Spa_Img, Spa_Wei]   =  Patch2Cub( EPat, W, Par.patsize, Height, Width, Band );       % Patch to Cubic
    E_Img = Spa_Img./Spa_Wei;
    %%
   % PSNR  = csnr(O_Img*255, E_Img*255, 0, 0 );
%     if PSNR >= psnr_p
%         Re_PSNR = PSNR;
%         k_iter  = iter;
%     else
%         Re_PSNR = psnr_p;
%         k_iter  = iter - 1;
%     end
%     if PSNR - psnr_p < 0.15
%         break
%     end
%     psnr_p = PSNR;
% fprintf( 'Iter = %2.3f, PSNR = %2.2f\n', iter, PSNR);
end
return;


